-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 31, 2017 at 04:13 PM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 5.6.32-1+ubuntu16.04.1+deb.sury.org+2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jwest`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` tinyint(1) NOT NULL,
  `last_login` varchar(15) NOT NULL,
  `added_on` varchar(15) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `role`, `last_login`, `added_on`, `status`) VALUES
(1, 'Dheeraj thedijje', 'thedijje.ic@gmail.com', '601f1889667efaebb33b8c12572835da3f027f78', 1, '1514477869', '1465850211', 0),
(2, 'UTKARSH JAIN', 'admin@jwest.in', '601f1889667efaebb33b8c12572835da3f027f78', 1, '1514613855', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blog_post`
--

CREATE TABLE `blog_post` (
  `post_id` int(10) NOT NULL,
  `post_title` varchar(100) NOT NULL,
  `post_url` varchar(100) NOT NULL,
  `post_meta_detail` varchar(200) NOT NULL,
  `post_meta_keyword` varchar(200) NOT NULL,
  `post_content` text NOT NULL,
  `post_by` int(5) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_featured_image` varchar(200) NOT NULL,
  `post_view` int(10) NOT NULL,
  `post_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog_post`
--

INSERT INTO `blog_post` (`post_id`, `post_title`, `post_url`, `post_meta_detail`, `post_meta_keyword`, `post_content`, `post_by`, `created_on`, `updated_on`, `post_featured_image`, `post_view`, `post_status`) VALUES
(1, 'Man must explore, and this is exploration at its greatest', 'my-first-post', 'Man must explore, and this is exploration at its greatest', 'first,blog,post', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Pellentesque in ipsum id orci porta dapibus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Sed porttitor lectus nibh. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh.\r\n\r\nPraesent sapien massa, convallis a pellentesque nec, egestas non nisi. Donec sollicitudin molestie malesuada. Cras ultricies ligula sed magna dictum porta. Pellentesque in ipsum id orci porta dapibus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Pellentesque in ipsum id orci porta dapibus. Cras ultricies ligula sed magna dictum porta. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Sed porttitor lectus nibh. Lorem ipsum dolor sit amet, consectetur adipiscing elit.\r\n\r\nSed porttitor lectus nibh. Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus nibh. Curabitur aliquet quam id dui posuere blandit. Pellentesque in ipsum id orci porta dapibus. Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 1, '2017-04-28 12:51:24', '0000-00-00 00:00:00', '#', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(250) NOT NULL,
  `category_description` text NOT NULL,
  `category_code` varchar(250) NOT NULL,
  `parent_category` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `category_description`, `category_code`, `parent_category`) VALUES
(2, 'Short Kurtas', 'All Short Kurtas', 'KURTA-SHORT-001', 6),
(5, 'Maxi Gown', 'All Maxi Gown', 'DRESS-MAXI-002', 7),
(6, 'KURTA', 'All Kurta', 'KURTA-001', 0),
(7, 'DRESSES', 'ALL DRESSES', 'DRESS-001', 0);

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `id` int(10) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'site',
  `name` varchar(100) NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='configuration settings of site';

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `type`, `name`, `value`) VALUES
(1, 'site', 'sitename', 'Jwest'),
(2, 'site', 'home_title', 'Welcome: Jwest Cloth Store'),
(29, 'site', 'author', 'Dheeraj thedijje'),
(3, 'site', 'logo', 'static/front/img/logo/app_logo.png'),
(4, 'site', 'meta_detail', 'Jwest Cloth Store'),
(5, 'site', 'phone', '8826810280'),
(7, 'site', 'email', 'admin@jwest.in'),
(8, 'site', 'home_text', 'Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Proin eget tortor risus. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan ti'),
(10, 'site', 'sending_email', 'no-replay@thedijje.com'),
(9, 'site', 'date_format', 'd M Y'),
(11, 'site', 'sending_email_name', 'BusinessToday'),
(15, 'site', 'slider_w', '1903'),
(16, 'site', 'slider_h', '610'),
(19, 'site', 'address', 'ssss'),
(20, 'site', 'fax', ''),
(32, 'site', 'github', 'jwest'),
(22, 'site', 'device_auth_key', 'Y_DEVICE_AUTH'),
(23, 'site', 'free_sub_days', '30'),
(24, 'site', 'paypal_payment_email', 'jwest@gmail.com'),
(31, 'site', 'facebook', 'www.facebook.com'),
(30, 'site', 'twitter', 'www.twitter.com'),
(33, 'site', 'landline', '012411111112'),
(34, 'site', 'mobile', '9876543211'),
(35, 'site', 'facebook', 'www.facebook.com'),
(36, 'site', 'twitter', 'www.twitter.com'),
(37, 'site', 'instagram', 'http://www.instagram.com'),
(38, 'site', 'skype', 'jwest'),
(39, 'site', 'address', 'ssss'),
(40, 'site', 'testimonial_image_h', '101'),
(41, 'site', 'testimonial_image_w', '101');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `contact_id` int(10) NOT NULL,
  `contact_name` varchar(50) NOT NULL,
  `contact_email` varchar(50) NOT NULL,
  `contact_phone` varchar(15) NOT NULL,
  `contact_message` text NOT NULL,
  `contact_subject` varchar(250) NOT NULL,
  `contact_sent_on` varchar(15) NOT NULL,
  `contact_seen_on` varchar(15) NOT NULL,
  `contact_ip_address` varchar(15) NOT NULL,
  `contact_status` tinyint(1) NOT NULL DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`contact_id`, `contact_name`, `contact_email`, `contact_phone`, `contact_message`, `contact_subject`, `contact_sent_on`, `contact_seen_on`, `contact_ip_address`, `contact_status`) VALUES
(10, 'Dheeraj', 'thedijje.ic@gmail.com', '56878675', 'Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Proin eget tortor risus. Cras ultricies ligula sed magna dictum porta. Donec sollicitudin molestie malesuada. Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Donec rutrum congue leo eget malesuada. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.', '', '1475851976', '', '182.68.220.30', 3),
(11, 'Dheeraj', 'nmxdheeraj@gmail.com', '123123', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec sollicitudin molestie malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus suscipit tortor eget felis porttitor volutpat. Cras ultricies ligula sed magna dictum porta. Pellentesque in ipsum id orci porta dapibus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat.', '', '1476310487', '', '182.68.179.80', 3),
(12, 'Dheeraj', 'nmxdheeraj@gmail.com', '123123123', 'Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla porttitor accumsan tincidunt. Sed porttitor lectus nibh. Donec rutrum congue leo eget malesuada. Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus nibh.', '', '1476310570', '1514625375', '182.68.179.80', 1),
(14, 'Dheeraj', 'nmxdheeraj@gmail.com', '767908-89765', 'jhjkhlkh', '', '1476310931', '1514625974', '182.68.179.80', 1),
(15, 'Dheeraj', 'nmxdheeraj@gmail.com', '0987654345678', 'Donec rutrum congue leo eget malesuada. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Nulla porttitor accumsan tincidunt. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Donec rutrum congue leo eget malesuada. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Nulla quis lorem ut libero malesuada feugiat.', '', '1476311017', '1514625864', '182.68.179.80', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `menu_name` varchar(250) NOT NULL,
  `menu_link` varchar(255) NOT NULL,
  `menu_order` int(11) NOT NULL,
  `parent_menu` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `menu_name`, `menu_link`, `menu_order`, `parent_menu`) VALUES
(1, 'HOME', 'home', 1, 0),
(2, 'About Us', 'about-us', 2, 0),
(3, 'Top Category', 'top-category', 3, 0),
(4, 'Social Junction', 'social-junction', 4, 0),
(5, 'Sale', 'sale', 5, 0),
(6, 'Blog', 'blog', 6, 0),
(8, 'Contact us', 'contact-us', 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `module_id` int(10) NOT NULL,
  `module_name` varchar(30) NOT NULL,
  `module_slug` varchar(50) NOT NULL,
  `module_content` text NOT NULL,
  `module_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `page_id` int(10) NOT NULL,
  `page_title` varchar(150) NOT NULL,
  `page_url` varchar(150) NOT NULL,
  `page_head_image` varchar(250) NOT NULL,
  `page_content` text NOT NULL,
  `page_added_on` varchar(15) NOT NULL,
  `page_visit` int(10) NOT NULL,
  `page_meta_keyword` varchar(250) NOT NULL,
  `page_meta_description` text NOT NULL,
  `page_status` tinyint(1) NOT NULL DEFAULT '4'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`page_id`, `page_title`, `page_url`, `page_head_image`, `page_content`, `page_added_on`, `page_visit`, `page_meta_keyword`, `page_meta_description`, `page_status`) VALUES
(3, 'Terms and conditions', 'terms-and-conditions', '', '<div class="heading-part mb_20 mt_20" style="box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; border-bottom: 3px solid rgb(229, 229, 229); display: inline-block; width: 1290px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<h2 class="main_title" style="box-sizing: border-box; line-height: 36px; color: rgb(0, 0, 0); margin-top: 0px; margin-bottom: 0px; font-size: 20px; float: left;">\r\n		Terms &amp; conditions</h2>\r\n</div>\r\n<p class="mb_20" style="box-sizing: border-box; margin: 0px 0px 20px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion knows that you care about how your personal information is used and shared and we will make sure that it is taken care of and protected. Please read the following to learn more about our privacy policy. By visiting the Jwest Fashion website and domain name, and any other linked pages, features, content, or application services offered from time to time by Company in connection therewith (collectively, the &quot;Website&quot;), or using any of our services, you acknowledge that you accept the practices and policies outlined in this Privacy Policy.</p>\r\n<p class="mb_20" style="box-sizing: border-box; margin: 0px 0px 20px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	The information we gather from customers enables us to personalize and improve our services, and to allow our users to set up a user account and make purchases via the Website. We collect the following types of information from our customers.</p>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion keeps track of your information to offer you the best possible shopping experience. When you register (log in), you supply your email address and a password. This allows us to access to your account every time you visit our Website. Before completing your first purchase, we also ask you for your name, phone number, email, billing and shipping addresses. This information, along with your credit card number, is necessary to fulfill your order. This information may be disclosed to specific members of our staff and to select third parties (such as our credit card processor and shipping provider) involved in the completion of your transaction and delivery of your order. We may also need your email address or phone number to contact you if we have questions about your order. We may also use your email address to notify you about new services or special promotional programs, or send you offers or information if you have opted-in. Emails are sent only to Jwest Fashion members who have chosen to receive them (opted-in) or who have made a purchase on our website. At any time, you can notify us that you wish to stop receiving these emails. In addition, we keep a record of your past purchases, returns, and credits. We may also ask you for information regarding your personal preferences and demographics to help us better meet your needs.&nbsp;</p>\r\n<p class="mb_20" style="box-sizing: border-box; margin: 0px 0px 20px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion uses reporting software that allows us to analyze the amount and type of member traffic we get on our Website. We use this data to make improvements to your shopping experience and to ensure that we have enough capacity to properly serve all of our members. The software provides aggregate reporting information to Jwest Fashion only. No personal or personally identifiable information is gathered or used for this process.</p>\r\n<p class="mb_20" style="box-sizing: border-box; margin: 0px 0px 20px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	In an effort to make our Website as effective and enjoyable as possible, the computers that operate it collect certain information each time you visit. We store these statistics in server logs. Once again, these statistics do not identify you personally, but provide us information regarding the type of user who is accessing our Website and certain browsing activities of that user. This data may include: the IP address of the user accessing our Website (i.e. the unique I.D. number of the user&#39;s computer), the type of browser (Internet Explorer, Firefox, etc.) and the operating system (Windows, Mac OS, etc.), the Website the user last visited before linking to our Website, how long the user accessed our Website in any given session, and the date and time of access. We may make extensive use of this data at an aggregated level in order to understand how our Website is being used</p>\r\n<p class="mb_20" style="box-sizing: border-box; margin: 0px 0px 20px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion is committed to protecting all the information you share with us. We follow stringent procedures to help protect the confidentiality, security, and integrity of data stored on our systems The Site encrypts your credit card number and other personal information using secure socket layer (SSL) technology to provide for the secure transmission of the information from your PC to our servers.&nbsp;.Only those employees who need access to your information in order to perform their duties are allowed such access. Any employee who violates our privacy and/or security policies is subject to disciplinary action, including possible termination and civil and/or criminal prosecution.</p>\r\n', '1472370878', 0, 'Terms and conditions', 'Terms and conditions', 1),
(4, 'Policy', 'policy', '', '<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion knows that you care about how your personal information is used and shared and we will make sure that it is taken care of and protected. Please read the following to learn more about our privacy policy. By visiting the Jwest Fashion website and domain name, and any other linked pages, features, content, or application services offered from time to time by Company in connection therewith (collectively, the &quot;Website&quot;), or using any of our services, you acknowledge that you accept the practices and policies outlined in this Privacy Policy.</p>\r\n<div class="heading-part mb_20 mt_20" style="box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; border-bottom: 3px solid rgb(229, 229, 229); display: inline-block; width: 1290px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<h2 class="main_title" style="box-sizing: border-box; line-height: 36px; color: rgb(0, 0, 0); margin-top: 0px; margin-bottom: 0px; font-size: 20px; float: left;">\r\n		What does this Privacy Policy cover?</h2>\r\n</div>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	This Privacy Policy covers Company&#39;s treatment of personally identifiable information (&quot;Personal Information&quot;) that Company gathers when you are accessing Company&#39;s Website and when you use Company services. This policy does not apply to the practices of companies that Company does not own or control, or to individuals that Company does not employ or manage.</p>\r\n<div class="heading-part mb_20 mt_20" style="box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; border-bottom: 3px solid rgb(229, 229, 229); display: inline-block; width: 1290px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<h2 class="main_title" style="box-sizing: border-box; line-height: 36px; color: rgb(0, 0, 0); margin-top: 0px; margin-bottom: 0px; font-size: 20px; float: left;">\r\n		How does Jwest Fashion Gather and Use Information?</h2>\r\n</div>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	The information we gather from customers enables us to personalize and improve our services, and to allow our users to set up a user account and make purchases via the Website. We collect the following types of information from our customers.</p>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion keeps track of your information to offer you the best possible shopping experience. When you register (log in), you supply your email address and a password. This allows us to access to your account every time you visit our Website. Before completing your first purchase, we also ask you for your name, phone number, email, billing and shipping addresses. This information, along with your credit card number, is necessary to fulfill your order. This information may be disclosed to specific members of our staff and to select third parties (such as our credit card processor and shipping provider) involved in the completion of your transaction and delivery of your order. We may also need your email address or phone number to contact you if we have questions about your order. We may also use your email address to notify you about new services or special promotional programs, or send you offers or information if you have opted-in. Emails are sent only to Jwest Fashion members who have chosen to receive them (opted-in) or who have made a purchase on our website. At any time, you can notify us that you wish to stop receiving these emails. In addition, we keep a record of your past purchases, returns, and credits. We may also ask you for information regarding your personal preferences and demographics to help us better meet your needs.&nbsp;</p>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<strong style="box-sizing: border-box;">Cookies:</strong>&nbsp;Cookies are alphanumeric identifiers that we transfer to your computer&#39;s hard drive through your browser to enable our systems to recognize your browser and tell us how and when pages in our site are visited and by how many people. Company cookies do not collect Personal Information, and we do not combine the general information collected through cookies with other Personal Information to tell us who you are or what your screen name or email address is.</p>\r\n<div class="heading-part mb_20 mt_20" style="box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; border-bottom: 3px solid rgb(229, 229, 229); display: inline-block; width: 1290px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<h2 class="main_title" style="box-sizing: border-box; line-height: 36px; color: rgb(0, 0, 0); margin-top: 0px; margin-bottom: 0px; font-size: 20px; float: left;">\r\n		Server statistics</h2>\r\n</div>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion uses reporting software that allows us to analyze the amount and type of member traffic we get on our Website. We use this data to make improvements to your shopping experience and to ensure that we have enough capacity to properly serve all of our members. The software provides aggregate reporting information to Jwest Fashion only. No personal or personally identifiable information is gathered or used for this process.</p>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	In an effort to make our Website as effective and enjoyable as possible, the computers that operate it collect certain information each time you visit. We store these statistics in server logs. Once again, these statistics do not identify you personally, but provide us information regarding the type of user who is accessing our Website and certain browsing activities of that user. This data may include: the IP address of the user accessing our Website (i.e. the unique I.D. number of the user&#39;s computer), the type of browser (Internet Explorer, Firefox, etc.) and the operating system (Windows, Mac OS, etc.), the Website the user last visited before linking to our Website, how long the user accessed our Website in any given session, and the date and time of access. We may make extensive use of this data at an aggregated level in order to understand how our Website is being used</p>\r\n<div class="heading-part mb_20 mt_20" style="box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; border-bottom: 3px solid rgb(229, 229, 229); display: inline-block; width: 1290px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<h2 class="main_title" style="box-sizing: border-box; line-height: 36px; color: rgb(0, 0, 0); margin-top: 0px; margin-bottom: 0px; font-size: 20px; float: left;">\r\n		What Security Procedures Does Jwest Fashion Use To Protect Personal Information?</h2>\r\n</div>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion is committed to protecting all the information you share with us. We follow stringent procedures to help protect the confidentiality, security, and integrity of data stored on our systems The Site encrypts your credit card number and other personal information using secure socket layer (SSL) technology to provide for the secure transmission of the information from your PC to our servers.&nbsp;.Only those employees who need access to your information in order to perform their duties are allowed such access. Any employee who violates our privacy and/or security policies is subject to disciplinary action, including possible termination and civil and/or criminal prosecution.</p>\r\n<div class="heading-part mb_20 mt_20" style="box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; border-bottom: 3px solid rgb(229, 229, 229); display: inline-block; width: 1290px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<h2 class="main_title" style="box-sizing: border-box; line-height: 36px; color: rgb(0, 0, 0); margin-top: 0px; margin-bottom: 0px; font-size: 20px; float: left;">\r\n		Service Providers</h2>\r\n</div>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion may use various outside agencies (third party service providers) to operate the website. For example, we may use third parties to host our Website, operate various features made available on our Website, send emails, analyze data, provide search results and links, and assist in fulfilling your orders. Some of these third parties may need access to your information in order to make the services provided through our Website work. Information will only be disclosed to these service providers on a need-to-know basis, and they will only be permitted to use such information for the purpose of providing the particular services provided by such entities in connection with our Website.</p>\r\n<div class="heading-part mb_20 mt_20" style="box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; border-bottom: 3px solid rgb(229, 229, 229); display: inline-block; width: 1290px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<h2 class="main_title" style="box-sizing: border-box; line-height: 36px; color: rgb(0, 0, 0); margin-top: 0px; margin-bottom: 0px; font-size: 20px; float: left;">\r\n		Exceptions</h2>\r\n</div>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion may be forced to disclose information in order to comply with a subpoena, court order, administrative or governmental order, or any other requirement of law, or Jwest Fashion, in its sole discretion, deems it necessary in order to protect our rights or the rights of others, to prevent harm to persons or property, to fight fraud and credit risk, or to enforce or apply our Website terms of use. Personally identifiable information may be transferred as an asset in connection with a merger or sale (including any transfers made as part of an insolvency or bankruptcy proceeding) involving all or part of our business or as part of a corporate reorganization, stock sale, or other change in control.</p>\r\n<div class="heading-part mb_20 mt_20" style="box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; border-bottom: 3px solid rgb(229, 229, 229); display: inline-block; width: 1290px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<h2 class="main_title" style="box-sizing: border-box; line-height: 36px; color: rgb(0, 0, 0); margin-top: 0px; margin-bottom: 0px; font-size: 20px; float: left;">\r\n		Children&#39;s Privacy and Parental Controls</h2>\r\n</div>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	We do not solicit any personal information from children. If you are not 18 or older, you are not authorized to use the Site. Parents should be aware that there are parental control tools available online that you can use to prevent your children from submitting information online without parental permission or from accessing material that is harmful to minors.</p>\r\n<div class="heading-part mb_20 mt_20" style="box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; border-bottom: 3px solid rgb(229, 229, 229); display: inline-block; width: 1290px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	<h2 class="main_title" style="box-sizing: border-box; line-height: 36px; color: rgb(0, 0, 0); margin-top: 0px; margin-bottom: 0px; font-size: 20px; float: left;">\r\n		Modification and notification of changes</h2>\r\n</div>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	You acknowledge that this Privacy Policy is part of the Terms of Use and you unconditionally agree that using this Website signifies your assent to Jwest Fashion Privacy Policy. If you do not agree with this Privacy Policy, please do not use our Website. Your visit and any dispute over privacy is subject to this policy and our Terms of Use, including limitations on damages</p>\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(128, 128, 128); font-family: Raleway, sans-serif; font-size: 14px; letter-spacing: 0.5px;">\r\n	Jwest Fashion reserves the right to change the terms of use and this Privacy Policy, at any time. We will post any changes so that you are always aware of our policy. Unless stated otherwise, our current Privacy Policy applies to all information that we have about you and your account. We stand behind the promises we make, however, and will never materially change our policies and practices to make them less protective of customer information collected in the past without the consent of affected customers.</p>\r\n', '1514625115', 0, 'policy', 'policy', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_short_description` text NOT NULL,
  `product_full_description` text NOT NULL,
  `product_colors` varchar(255) NOT NULL,
  `product_categories` varchar(255) NOT NULL,
  `product_tags` varchar(255) NOT NULL,
  `product_featured_image` varchar(255) NOT NULL,
  `product_gallery_images` varchar(255) NOT NULL,
  `product_regular_price` varchar(255) NOT NULL,
  `product_sale_price` varchar(255) NOT NULL,
  `product_sku` varchar(255) NOT NULL,
  `product_stock_status` varchar(255) NOT NULL,
  `product_size` varchar(255) NOT NULL,
  `product_weight` varchar(255) NOT NULL,
  `product_length` varchar(255) NOT NULL,
  `product_width` varchar(255) NOT NULL,
  `product_height` varchar(255) NOT NULL,
  `product_purchase_notes` text NOT NULL,
  `product_important_notes` text NOT NULL,
  `is_featured` tinyint(4) NOT NULL DEFAULT '0',
  `added_by` int(11) NOT NULL,
  `added_on` varchar(255) NOT NULL,
  `last_modified` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products_gallery_images`
--

CREATE TABLE `products_gallery_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `order_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_colors`
--

CREATE TABLE `product_colors` (
  `id` int(11) NOT NULL,
  `color_name` varchar(255) NOT NULL,
  `color_code` varchar(255) NOT NULL,
  `color_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_colors`
--

INSERT INTO `product_colors` (`id`, `color_name`, `color_code`, `color_image`) VALUES
(1, 'WHITE', '#FFFFFF', ''),
(2, 'BLACK', '#000000', '');

-- --------------------------------------------------------

--
-- Table structure for table `product_sizes`
--

CREATE TABLE `product_sizes` (
  `id` int(11) NOT NULL,
  `size_name` varchar(255) NOT NULL,
  `size_code` varchar(255) NOT NULL,
  `size_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_sizes`
--

INSERT INTO `product_sizes` (`id`, `size_name`, `size_code`, `size_description`) VALUES
(1, 'Xtra Large', 'XL', '<p>\r\n	xl size</p>\r\n'),
(2, 'Largeeeeeeeee', 'LLLLLLLLLLLL', '<p>\r\n	Large Sizeee</p>\r\n'),
(4, 'Medium', 'M', '<p>\r\n	Medium</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `slides`
--

CREATE TABLE `slides` (
  `slide_id` int(10) NOT NULL,
  `slide_image` varchar(250) NOT NULL,
  `slide_big_text` varchar(100) NOT NULL,
  `sm_txt` varchar(100) NOT NULL,
  `slide_order` int(5) NOT NULL,
  `link_url` varchar(200) NOT NULL,
  `slide_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slides`
--

INSERT INTO `slides` (`slide_id`, `slide_image`, `slide_big_text`, `sm_txt`, `slide_order`, `link_url`, `slide_status`) VALUES
(7, 'static/images/slider/6be84d029cb4a9c1a73992fff3423056_1.jpg', 'Main Banner', '', 1, '', 1),
(8, 'static/images/slider/d91b5ca8847f9d7e151003f2507ca4cc_1.jpg', 'Main Banner 2', '', 2, '', 1),
(9, 'static/images/slider/5da2c612074769f04d4eb882fddd522f_2.jpg', 'Main Banner 3', '', 3, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `status_id` int(10) NOT NULL,
  `status_name` varchar(50) NOT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`status_id`, `status_name`, `enable`) VALUES
(1, 'Active', 1),
(2, 'Inactive', 1),
(3, 'Pending', 1),
(4, 'Rejected', 1);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(250) NOT NULL,
  `customer_image` varchar(250) NOT NULL,
  `testimonial_content` text NOT NULL,
  `added_on` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `customer_name`, `customer_image`, `testimonial_content`, `added_on`) VALUES
(1, 'UTKARSH JAIN', '', '<p>\r\n	THIS IS MY FIRST TESTING TESTIMONIAL</p>\r\n', '1514659990'),
(2, 'TESTING NAME', '', '<p>\r\n	MY SECOND TESTING TESTIMONIAL CONTENT. I HOPE YOU WILL DEFINITELY LIKE THIS. ALL THE BEST</p>\r\n', '1514661393'),
(3, 'YO YO HONEY SINGH', 'static/images/testimonials/794689f9dbf5243660800260adbcc47c_3.jpg', '<p>\r\n	YO YO YOYOYOYYOOYOYOYOYOYOOYYYOOYOYOYOYOOYYOOYOYOYOYOYOYOYOOYOYOYOYOYOYOYOYOYOYOYOYO</p>\r\n', '1514661642');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_post`
--
ALTER TABLE `blog_post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`),
  ADD UNIQUE KEY `url` (`page_url`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products_gallery_images`
--
ALTER TABLE `products_gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_colors`
--
ALTER TABLE `product_colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_sizes`
--
ALTER TABLE `product_sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slides`
--
ALTER TABLE `slides`
  ADD PRIMARY KEY (`slide_id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `blog_post`
--
ALTER TABLE `blog_post`
  MODIFY `post_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `contact_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products_gallery_images`
--
ALTER TABLE `products_gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product_colors`
--
ALTER TABLE `product_colors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `product_sizes`
--
ALTER TABLE `product_sizes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `slides`
--
ALTER TABLE `slides`
  MODIFY `slide_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `status_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
