<!-- =====  CONTAINER START  ===== --> 
  <div class="container">
  <div class="row ">
    <div class="col-md-12">
          <div class="heading-part mb_20 mt_40">
            <h2 class="main_title">FAQ</h2>
          </div>
<div class="panel-group" id="accordion">
            <div class="panel panel-default pull-left">
              <div class="panel-heading">
                <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">1. Lorem Ipsum is simply dummy text </a> </h4>
              </div>
              <div id="collapseOne" class="panel-collapse collapse in">
                <div class="panel-body">
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                </div>
              </div>
            </div>
            <div class="panel panel-default pull-left">
              <div class="panel-heading">
                <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">2.  Lorem Ipsum is simply dummy text</a> </h4>
              </div>
              <div id="collapseTwo" class="panel-collapse collapse">
                <div class="panel-body">
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                </div>
              </div>
            </div>
            <div class="panel panel-default pull-left">
              <div class="panel-heading">
                <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">3.  Lorem Ipsum is simply dummy text</a> </h4>
              </div>
              <div id="collapseThree" class="panel-collapse collapse">
                <div class="panel-body">
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                </div>
              </div>
            </div>
            
            <div class="panel panel-default pull-left">
              <div class="panel-heading">
                <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapsefour">3.  Lorem Ipsum is simply dummy text</a> </h4>
              </div>
              <div id="collapsefour" class="panel-collapse collapse">
                <div class="panel-body">
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                </div>
              </div>
            </div>
            
            
            <div class="panel panel-default pull-left">
              <div class="panel-heading">
                <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapsefive">4.  Lorem Ipsum is simply dummy text</a> </h4>
              </div>
              <div id="collapsefive" class="panel-collapse collapse">
                <div class="panel-body">
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                </div>
              </div>
            </div>
            
            <div class="panel panel-default pull-left">
              <div class="panel-heading">
                <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapsesix">5.  Lorem Ipsum is simply dummy text</a> </h4>
              </div>
              <div id="collapsesix" class="panel-collapse collapse">
                <div class="panel-body">
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                </div>
              </div>
            </div>
          </div>
        </div></div>
     <br>
<br>
    
     
          
    </div>
  </div>
</div>
  <!-- Single Blog  -->
  

<!-- End Blog 	-->

<!-- =====  CONTAINER END  ===== --> 