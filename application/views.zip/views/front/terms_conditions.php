<!-- =====  CONTAINER START  ===== --> 
  <div class="container">
  <div class="row ">
    <div class="col-md-12 mb_20 mt_40">
        
   <div class="heading-part mb_20 mt_20"><h2 class="main_title">Terms & conditions</h2></div>     
        
<p class="mb_20">Jwest Fashion knows that you care about how your personal information is used and shared and we will make sure that it is taken care of and protected. Please read the following to learn more about our privacy policy. By visiting the Jwest Fashion website and domain name, and any other linked pages, features, content, or application services offered from time to time by Company in connection therewith (collectively, the "Website"), or using any of our services, you acknowledge that you accept the practices and policies outlined in this Privacy Policy.</p>
 




<p class="mb_20">The information we gather from customers enables us to personalize and improve our services, and to allow our users to set up a user account and make purchases via the Website. We collect the following types of information from our customers.</p>

<p>Jwest Fashion keeps track of your information to offer you the best possible shopping experience. When you register (log in), you supply your email address and a password. This allows us to access to your account every time you visit our Website. Before completing your first purchase, we also ask you for your name, phone number, email, billing and shipping addresses. This information, along with your credit card number, is necessary to fulfill your order. This information may be disclosed to specific members of our staff and to select third parties (such as our credit card processor and shipping provider) involved in the completion of your transaction and delivery of your order. We may also need your email address or phone number to contact you if we have questions about your order. We may also use your email address to notify you about new services or special promotional programs, or send you offers or information if you have opted-in. Emails are sent only to Jwest Fashion members who have chosen to receive them (opted-in) or who have made a purchase on our website. At any time, you can notify us that you wish to stop receiving these emails. In addition, we keep a record of your past purchases, returns, and credits. We may also ask you for information regarding your personal preferences and demographics to help us better meet your needs.&nbsp;</p>






<p class="mb_20">Jwest Fashion uses reporting software that allows us to analyze the amount and type of member traffic we get on our Website. We use this data to make improvements to your shopping experience and to ensure that we have enough capacity to properly serve all of our members. The software provides aggregate reporting information to Jwest Fashion only. No personal or personally identifiable information is gathered or used for this process.</p>

<p class="mb_20">In an effort to make our Website as effective and enjoyable as possible, the computers that operate it collect certain information each time you visit. We store these statistics in server logs. Once again, these statistics do not identify you personally, but provide us information regarding the type of user who is accessing our Website and certain browsing activities of that user. This data may include: the IP address of the user accessing our Website (i.e. the unique I.D. number of the user's computer), the type of browser (Internet Explorer, Firefox, etc.) and the operating system (Windows, Mac OS, etc.), the Website the user last visited before linking to our Website, how long the user accessed our Website in any given session, and the date and time of access. We may make extensive use of this data at an aggregated level in order to understand how our Website is being used</p>





<p class="mb_20">Jwest Fashion is committed to protecting all the information you share with us. We follow stringent procedures to help protect the confidentiality, security, and integrity of data stored on our systems The Site encrypts your credit card number and other personal information using secure socket layer (SSL) technology to provide for the secure transmission of the information from your PC to our servers.&nbsp;.Only those employees who need access to your information in order to perform their duties are allowed such access. Any employee who violates our privacy and/or security policies is subject to disciplinary action, including possible termination and civil and/or criminal prosecution.</p>




        
        
        
        
      </div></div>
     <br>
<br>
    
     
          
  </div>
</div>
</div>
  <!-- Single Blog  -->
  

<!-- End Blog 	-->

<!-- =====  CONTAINER END  ===== --> 