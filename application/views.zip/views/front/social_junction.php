<!-- =====  CONTAINER START  ===== --> 
  <div class="container">
  <div class="row ">
    <div class="col-md-12 mb_20 mt_40">
        
   <div class="heading-part mb_20 mt_20"><h2 class="main_title">Social Junction</h2></div>     
        
<h1> Comng Soon</h1>




        
        
        
        
      </div></div>
     <br>
<br>
    
     
          
  </div>
</div>
</div>
  <!-- Single Blog  -->
  

<!-- End Blog 	-->

<!-- =====  CONTAINER END  ===== --> 