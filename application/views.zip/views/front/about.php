<div class="container">
  <div class="row ">
    
    
    
     <!-- =====  company image  Start  ===== --> 
    <div class="col-sm-5 mt_20"> 
   
     <img src="<?php echo base_url('static/front/') ?>img/about-page-gaando.jpg" class="img-rounded">
           
           
              
      <!-- =====  product ===== -->
      
      <!-- =====  end  ===== -->
     
      <!--Team Carousel -->
   

      </div>
    
         <div class="col-sm-7 mb_20" >
         
         <div class="about-text">
                    <div class="heading-part mb_20 mt_40">
            <h2 class="main_title">About us</h2>
          </div>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem
                  of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a  Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
                  
                 
              
             
            
    </div>
         
         
          <div class="about-text">
         <div class="heading-part mb_20 mt_40">
            <h2 class="main_title">What We have</h2>
          </div>
                 <ul class="content-list" style="left:0px;">
                    <li>Kurtas</li>
                    <li>Dresses</li>
                    <li>Tops</li>
                    <li>Jackets</li>
                    <li>Skirts</li>
                    <li>Suits</li>
                    <li>Accessories</li>
                     <li>Bottoms</li>
                  </ul>
      </div></div>
      
      <!-- =====  company image end  ===== --> 
      
      <!-- ===== about  content  ===== -->
      
          
    </div>
    
    
    <div class="row">
    <div class="col-sm-6">
    <div class="about-text">
         <div class="heading-part mb_20 mt_40">
            <h2 class="main_title">Our Vision</h2>
          </div>
                  <p> Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem
                  of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a  Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
      </div>
      </div>
      
      <div class="col-sm-6">
    <div class="about-text">
         <div class="heading-part mb_20 mt_40">
            <h2 class="main_title">Why Choose Jwest</h2>
          </div>
                  <p> Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem
                  of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a  Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
      </div>
          <br>
<br>
<br>
      </div>
      


    </div>
    
    
  </div>
</div>
  <!-- Single Blog  -->
  

<!-- End Blog   -->

<!-- =====  CONTAINER END  ===== --> 