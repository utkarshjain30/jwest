<!-- =====  CONTAINER START  ===== -->

<div class="container">
  <div class="row ">
   
      
      
    <div class="col-sm-12 col-md-12 col-lg-12 mtb_40"> 
    
        <div class="row">
        <div class="three-col-blog text-left">
          <div class="blog-item col-md-6 mb_30">
              <div class="post-format">
                <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_04.jpg"  alt="fastro"></a></div>
                <div class="post-type"><i class="fa fa-music" aria-hidden="true"></i></div>
              </div>
              <div class="post-info mtb_20 ">
                <h3 class="mb_10"> <a href="#">Fashions fade, style is eternal</a> </h3>
                <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                <div class="details mtb_20">
                  <div class="date pull-left"> <i class="fa fa-calendar" aria-hidden="true"></i>11 May 2017 </div>
                  <div class="more pull-right"> <a href="#">Read more <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></div>
                </div>
              </div>
            </div>
            <div class="blog-item col-md-6 mb_30">
              <div class="post-format">
                <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_05.jpg"  alt="fastro"></a></div>
                <div class="post-type"><i class="fa fa-music" aria-hidden="true"></i></div>
              </div>
              <div class="post-info mtb_20 ">
                <h3 class="mb_10"> <a href="#">Fashions fade, style is eternal</a> </h3>
                <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                <div class="details mtb_20">
                  <div class="date pull-left"> <i class="fa fa-calendar" aria-hidden="true"></i>11 May 2017 </div>
                  <div class="more pull-right"> <a href="#">Read more <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></div>
                </div>
              </div>
            </div>
            <div class="blog-item col-md-6 mb_30">
              <div class="post-format">
                <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_06.jpg"  alt="fastro"></a></div>
                <div class="post-type"><i class="fa fa-music" aria-hidden="true"></i></div>
              </div>
              <div class="post-info mtb_20 ">
                <h3 class="mb_10"> <a href="#">Fashions fade, style is eternal</a> </h3>
                <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                <div class="details mtb_20">
                  <div class="date pull-left"> <i class="fa fa-calendar" aria-hidden="true"></i>11 May 2017 </div>
                  <div class="more pull-right"> <a href="#">Read more <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></div>
                </div>
              </div>
            </div>
            <div class="blog-item col-md-6 mb_30">
              <div class="post-format">
                <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_07.jpg"  alt="fastro"></a></div>
                <div class="post-type"><i class="fa fa-music" aria-hidden="true"></i></div>
              </div>
              <div class="post-info mtb_20 ">
                <h3 class="mb_10"> <a href="#">Fashions fade, style is eternal</a> </h3>
                <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                <div class="details mtb_20">
                  <div class="date pull-left"> <i class="fa fa-calendar" aria-hidden="true"></i>11 May 2017 </div>
                  <div class="more pull-right"> <a href="#">Read more <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></div>
                </div>
              </div>
            </div>
            <div class="blog-item col-md-6 mb_30">
              <div class="post-format">
                <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_08.jpg"  alt="fastro"></a></div>
                <div class="post-type"><i class="fa fa-music" aria-hidden="true"></i></div>
              </div>
              <div class="post-info mtb_20 ">
                <h3 class="mb_10"> <a href="#">Fashions fade, style is eternal</a> </h3>
                <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                <div class="details mtb_20">
                  <div class="date pull-left"> <i class="fa fa-calendar" aria-hidden="true"></i>11 May 2017 </div>
                  <div class="more pull-right"> <a href="#">Read more <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></div>
                </div>
              </div>
            </div>
            <div class="blog-item col-md-6 mb_30">
              <div class="post-format">
                <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_01.jpg"  alt="fastro"></a></div>
                <div class="post-type"><i class="fa fa-music" aria-hidden="true"></i></div>
              </div>
              <div class="post-info mtb_20 ">
                <h3 class="mb_10"> <a href="#">Fashions fade, style is eternal</a> </h3>
                <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                <div class="details mtb_20">
                  <div class="date pull-left"> <i class="fa fa-calendar" aria-hidden="true"></i>11 May 2017 </div>
                  <div class="more pull-right"> <a href="#">Read more <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></div>
                </div>
              </div>
            </div>
            <div class="blog-item col-md-6 mb_30">
              <div class="post-format">
                <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_02.jpg"  alt="fastro"></a></div>
                <div class="post-type"><i class="fa fa-music" aria-hidden="true"></i></div>
              </div>
              <div class="post-info mtb_20 ">
                <h3 class="mb_10"> <a href="#">Fashions fade, style is eternal</a> </h3>
                <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                <div class="details mtb_20">
                  <div class="date pull-left"> <i class="fa fa-calendar" aria-hidden="true"></i>11 May 2017 </div>
                  <div class="more pull-right"> <a href="#">Read more <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></div>
                </div>
              </div>
            </div>
            <div class="blog-item col-md-6 mb_30">
              <div class="post-format">
                <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_03.jpg"  alt="fastro"></a></div>
                <div class="post-type"><i class="fa fa-music" aria-hidden="true"></i></div>
              </div>
              <div class="post-info mtb_20 ">
                <h3 class="mb_10"> <a href="#">Fashions fade, style is eternal</a> </h3>
                <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                <div class="details mtb_20">
                  <div class="date pull-left"> <i class="fa fa-calendar" aria-hidden="true"></i>11 May 2017 </div>
                  <div class="more pull-right"> <a href="#">Read more <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></div>
                </div>
              </div>
            </div>
          </div>
 
        </div>
        <div class="pagination-nav text-center mtb_20">
            <ul>
              <li><a href="#"><i class="fa fa-angle-left"></i></a></li>
              <li class="active"><a href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
            </ul>
          </div>
      </div>
          
    </div>
  </div>
</div>
<!-- =====  CONTAINER END  ===== --> 