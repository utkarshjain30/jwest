<!-- =====  BANNER START  ===== -->
  <div class="banner">
    <div class="main-banner owl-carousel">
      <?php $sliders = $this->lib->get_table('slides',array('slide_id'=>'asc'));
      foreach($sliders as $slide){ ?>
        <div class="item"><a href="#"><img src="<?php echo $slide->slide_image ?>" alt="Main Banner" class="img-responsive" /></a></div>
      <?php } ?>
    </div>
  </div>
  <!-- =====  BANNER END  ===== --> 
  
  <!-- =====  CONTAINER START  ===== -->
  <div class="container">
    <div class="row ">
      <div class="col-sm-12 mtb_30"> 
        
        <!-- =====  SUB BANNER  STRAT ===== -->
        <div class="row">
          <div class="cms_banner mt_10">
            <div class="col-xs-5 col-sm-5 col-md-5 mt_20">
              <div id="subbanner1" class="sub-hover"> <a href="#"><img src="<?php echo base_url('static/front/') ?>img/sub1.jpg" alt="Sub Banner1" class="img-responsive"></a> 
                <!--  <div class="bannertext">
                <h2><span>use code : </span>suitup <br>online only.</h2>
              </div>--> 
              </div>
            </div>
            <div class="col-xs-7 col-sm-7 col-md-7 mt_20">
              <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                  <div id="subbanner2" class="sub-hover"> <a href="#"><img src="<?php echo base_url('static/front/') ?>img/sub2.jpg" alt="Sub Banner2" class="img-responsive"></a>
                    <div class="bannertext">
                      <h2>New <br>
                        Western<br>
 Dresses</h2>
                      <p class="mt_10">Discover wide range</p>
                    </div>
                  </div>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6">
                  <div id="subbanner3" class="sub-hover"> <a href="#"><img src="<?php echo base_url('static/front/') ?>img/sub3.jpg" alt="Sub Banner3" class="img-responsive"></a>
                    <div class="bannertext">
                      <h2>Shoes <br>
                        & Footwear</h2>
                      <p class="mt_10">Fashionable lifestyle</p>
                    </div>
                  </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 mt_30">
                  <div id="subbanner4" class="sub-hover"> <a href="#"><img src="<?php echo base_url('static/front/') ?>img/sub4.jpg" alt="Sub Banner4" class="img-responsive"></a>
                    <div class="bannertext">
                      <h2>Latest Fashion</h2>
                      <button class="btn mt_10">Shop now</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- =====  SUB BANNER END  ===== --> 
        
        <!-- =====  PRODUCT TAB  ===== -->
        <div id="product-tab" class="mt_30">
          <div class="row">
            <div class="col-md-6">
              <div  class="new-arrival-code"><a href="#nArrivals" data-toggle="tab">New Arrivals</a></div>
            </div>
            <div class="col-md-6">
              <div class="new-arrival-code"><a href="#Featured" data-toggle="tab">Featured</a> </div>
            </div>
          </div>
          <!-- <div class="heading-part mb_20 ">
          <h2 class="main_title">Jwast Cloths</h2>
        </div>--> 
          
          <!-- <ul class="nav text-right">
          <li class="active"> <a href="#nArrivals" data-toggle="tab">New Arrivals</a> </li>
          <li><a href="#Featured" data-toggle="tab">Featured</a> </li>
        </ul>-->
          <div class="tab-content clearfix box">
           <div class="col-md-6"> <div class="tab-pane active" id="nArrivals">
              <div class="nArrivals owl-carousel">
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product9.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product9-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product10.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product10-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product1-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product2.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product2-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product3.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product3-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product4.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product4-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product5.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product5-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product6.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product6-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product7.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product7-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product8.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product8-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product9.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product9-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product10.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product10-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
              </div>
            </div></div>
           <div class="col-md-6"> 
           
           <div class="tab-pane" id="Featured">
           
              <div class="Featured owl-carousel">
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product2.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product2-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product3.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product3-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product4.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product4-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product5.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product5-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product6.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product6-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product7.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product7-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product8.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product8-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product9.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product9-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product10.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product10-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product1-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
                <div class="product-grid">
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product2.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product2-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="product-thumb  mb_30">
                      <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product3.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product3-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    </div>
                  </div>
                </div>
              </div>
            </div></div>
          </div>
        </div>
        <!-- =====  PRODUCT TAB  END ===== --> 
        <!-- =====  SUB BANNER  STRAT ===== -->
        <div class="row">
          <div class="cms_banner mt_40 mb_60">
            <div class="col-xs-12">
              <div id="subbanner5" class="banner"> <a href="#"><img src="<?php echo base_url('static/front/') ?>img/sub5.png" alt="Sub Banner5" class="img-responsive"></a>
                <div class="bannertext">
                  <h2>Collection of Women's bag</h2>
                  <span>Buy Latest Design Women Bags Purses, Wallets, Clutches</span>
                  <button class="btn">Shop now</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- =====  SUB BANNER END  ===== -->
        
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-8 col-lg-9"> 
            <!-- =====  sale product  ===== -->
            <div id="sale-product">
              <div class="heading-part mb_20 ">
                <h2 class="main_title">Latest Products </h2>
              </div>
              <div class="Specials owl-carousel">
                <div class="item product-layout product-list">
                  <div class="product-thumb">
                    <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product8.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product8-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    <div class="caption product-detail text-left">
                      <h6 data-name="product_name" class="product-name"><a href="#" title="Casual Shirt With Ruffle Hem">Product Name</a></h6>
                      <p class="product-desc mt_20"> More room to move. With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.Cover Flow. Browse through your music collection by flipping..</p>
                    </div>
                  </div>
                </div>
                <div class="item product-layout product-list">
                  <div class="product-thumb">
                    <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product7.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product7-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    <div class="caption product-detail text-left">
                      <h6 data-name="product_name" class="product-name"><a href="#" title="Casual Shirt With Ruffle Hem">Product Name</a></h6>
                      <p class="product-desc mt_20"> More room to move. With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.Cover Flow. Browse through your music collection by flipping..</p>
                    </div>
                  </div>
                </div>
                <div class="item product-layout product-list">
                  <div class="product-thumb">
                    <div class="image product-imageblock"> <a href="<?php echo base_url('product-detail') ?>"> <img data-name="product_image" src="<?php echo base_url('static/front/') ?>img/product6.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="<?php echo base_url('static/front/') ?>img/product6-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                    <div class="caption product-detail text-left">
                      <h6 data-name="product_name" class="product-name"><a href="#" title="Casual Shirt With Ruffle Hem">Product Name</a></h6>
                      <p class="product-desc mt_20"> More room to move. With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.Cover Flow. Browse through your music collection by flipping..</p>
                      <!--<div class="timer mt_80">
                  <div class="days"></div>
                  <div class="hours"></div>
                  <div class="minutes"></div>
                  <div class="seconds"></div>
                </div>--> 
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- =====  sale product end ===== --> 
          </div>
          <!-- =====  testimonial  ===== -->
          <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
            <div class="Testimonial right-sidebar-widget" style="margin-bottom:30px;">
              <div class="heading-part mb_20 ">
                <h2 class="main_title">Testimonials</h2>
              </div>
              <div class="client owl-carousel text-center" >
                <?php $testimonials = $this->lib->get_table('testimonials',array('id'=>'asc'));
                foreach($testimonials as $test){ ?>
                  <div class="item client-detail">
                    <div class="client-avatar"> <img alt="" src="<?php echo base_url('').$test->customer_image; ?>"> </div>
                    <div class="client-title  mt_30"><strong><?php echo $test->customer_name; ?></strong></div>
                    <p><i class="fa fa-quote-left" aria-hidden="true"></i><?php echo $test->testimonial_content; ?></p>
                  </div>
                <?php } ?>
              </div>
            </div>
          </div>
          <!-- =====  testimonial end ===== --> 
        </div>
        
        <!-- =====  Blog ===== -->
        <div id="Blog" class="mt_30">
          <div class="heading-part mb_20 ">
            <h2 class="main_title">Latest from the Blog</h2>
          </div>
          <div class="blog-contain box">
            <div class="blog owl-carousel ">
              <div class="item">
                <div class="box-holder">
                  <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_01.jpg" alt="fastro"> </a> </div>
                  <div class="post-info mtb_20 ">
                    <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Fashions fade, style is eternal</a> </h6>
                    <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                    <div class="date-time">
                      <div class="day"> 11</div>
                      <div class="month">Aug</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="box-holder">
                  <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_02.jpg" alt="fastro"> </a></div>
                  <div class="post-info mtb_20 ">
                    <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Fashions fade, style is eternal</a> </h6>
                    <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                    <div class="date-time">
                      <div class="day"> 11</div>
                      <div class="month">Aug</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="box-holder">
                  <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_01.jpg" alt="fastro"> </a></div>
                  <div class="post-info mtb_20 ">
                    <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Fashions fade, style is eternal</a> </h6>
                    <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                    <div class="date-time">
                      <div class="day"> 11</div>
                      <div class="month">Aug</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="box-holder">
                  <div class="thumb post-img"><a href="#"> <img src="<?php echo base_url('static/front/') ?>img/blog_img_02.jpg" alt="fastro"> </a></div>
                  <div class="post-info mtb_20 ">
                    <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Fashions fade, style is eternal</a> </h6>
                    <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                    <div class="date-time">
                      <div class="day"> 11</div>
                      <div class="month">Aug</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- =====  Blog end ===== --> 
        </div>
      </div>
    </div>
  </div>
  <!-- =====  CONTAINER END  ===== --> 