<div class="content">

	<div class="container-widget">

	<div class="row">
	 <div class="col-md-12">
		  <div class="clearfix" style="height:500px;">

		
		  
		  </div>
		</div>
	</div>  

	</div>
