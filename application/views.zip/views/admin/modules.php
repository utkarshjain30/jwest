<div class="content">

	<div class="container-widget">

	<div class="row">
	 <div class="col-md-12">
		  <div class=" panel-widget widget chart-with-stats clearfix" style="height:500px;">

			<div class="col-sm-12" style="height:500px;">
			  
			</div>
		  
		  </div>
		</div>
	</div>  

	</div>
